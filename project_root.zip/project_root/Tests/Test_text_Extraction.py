#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Needed Packages

import pytesseract
import easyocr
import cv2
import os
import json
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'



USE_TESSERACT = True  


if USE_TESSERACT:
    pass
else:
    reader = easyocr.Reader(['en'])

#metadata
output_dir = "project_root/data/segmented_objects/"
metadata_path = os.path.join(output_dir, "your_metadata_file.json")

with open(metadata_path, "r") as f:
    metadata = json.load(f)

# Extract text/data from objects
for obj in metadata['objects']:
    object_img_path = os.path.join(output_dir, obj['file_name'])
    
    # Image Loading
    image = cv2.imread(object_img_path)
    
    if USE_TESSERACT:
        extracted_text = pytesseract.image_to_string(image)
    else:
        extracted_text = reader.readtext(image, detail=0)

    # Metadata Updation
    obj['extracted_text'] = extracted_text

# Saving
with open(metadata_path, "w") as f:
    json.dump(metadata, f, indent=4)

print("Text extraction completed and metadata updated.")


# In[ ]:




