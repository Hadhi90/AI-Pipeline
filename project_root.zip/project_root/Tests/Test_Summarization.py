#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Needed Packages

from transformers import pipeline
import json
import os

#summarization model
summarizer = pipeline("summarization")

#metadata file
output_dir = "project_root/data/segmented_objects/"
metadata_path = os.path.join(output_dir, "your_metadata_file.json")

with open(metadata_path, "r") as f:
    metadata = json.load(f)

# Summarizing 
for obj in metadata['objects']:
    if 'extracted_text' in obj and obj['extracted_text']:
        text = obj['extracted_text']
        
        
        summary = summarizer(text, max_length=150, min_length=30, do_sample=False)
        obj['summary'] = summary[0]['summary_text']
    else:
        obj['summary'] = "No text extracted"

# Save
with open(metadata_path, "w") as f:
    json.dump(metadata, f, indent=4)

print("Summarization completed and metadata updated.")


# In[ ]:




