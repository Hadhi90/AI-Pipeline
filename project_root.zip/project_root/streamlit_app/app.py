#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Needed Packages

import streamlit as st
import torch
from torchvision import models, transforms
from PIL import Image
import cv2
import os
import uuid
import json
import pytesseract
import easyocr
from transformers import pipeline
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#First we will define paths

INPUT_IMAGE_DIR = "data/input_images/"
SEGMENTED_OBJECTS_DIR = "data/segmented_objects/"
OUTPUT_DIR = "data/output/"
os.makedirs(SEGMENTED_OBJECTS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# then model initializing

mask_rcnn_model = models.detection.maskrcnn_resnet50_fpn(pretrained=True)
mask_rcnn_model.eval()
faster_rcnn_model = models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
faster_rcnn_model.eval()
transform = transforms.Compose([transforms.ToTensor()])
summarizer = pipeline("summarization")
USE_TESSERACT = True 


# For Streamlit app

st.title("AI Pipeline for Image Segmentation and Object Analysis")


uploaded_file = st.file_uploader("Choose an image...", type="jpg")

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image', use_column_width=True)
    
    image_tensor = transform(image).unsqueeze(0)
    
#Perform segmentation
    
    with torch.no_grad():
        predictions = mask_rcnn_model(image_tensor)
    
    masks = predictions[0]['masks'].numpy()
    boxes = predictions[0]['boxes'].numpy()

    original_image = np.array(image)
    master_id = str(uuid.uuid4())
    metadata = {"master_id": master_id, "objects": []}
    
    for i, (mask, box) in enumerate(zip(masks, boxes)):
        unique_id = str(uuid.uuid4())
        x_min, y_min, x_max, y_max = map(int, box)
        object_img = original_image[y_min:y_max, x_min:x_max]
        object_mask = mask[y_min:y_max, x_min:x_max]
        object_img = cv2.bitwise_and(object_img, object_img, mask=(object_mask > 0.5).astype("uint8"))
        object_filename = f"{unique_id}.png"
        cv2.imwrite(os.path.join(SEGMENTED_OBJECTS_DIR, object_filename), object_img)
        metadata["objects"].append({
            "unique_id": unique_id,
            "file_name": object_filename,
            "bounding_box": [x_min, y_min, x_max, y_max]
        })
    
    metadata_path = os.path.join(SEGMENTED_OBJECTS_DIR, f"{master_id}_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=4)

    st.success("Segmentation completed and objects saved.")
    
#Identify objects
    
    with open(metadata_path, "r") as f:
        metadata = json.load(f)
    
    for obj in metadata['objects']:
        object_img_path = os.path.join(SEGMENTED_OBJECTS_DIR, obj['file_name'])
        image = Image.open(object_img_path)
        image_tensor = transform(image).unsqueeze(0)
        with torch.no_grad():
            predictions = faster_rcnn_model(image_tensor)
        labels = predictions[0]['labels'].numpy()
        scores = predictions[0]['scores'].numpy()
        label_idx = scores.argmax()
        obj_label = labels[label_idx]
        obj_confidence = scores[label_idx]
        obj['label'] = str(obj_label)
        obj['confidence'] = float(obj_confidence)
    
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=4)

    st.success("Object identification completed and metadata updated.")

#Extract text/data from objects
    
    USE_TESSERACT = st.radio("Choose OCR tool", ("Tesseract", "EasyOCR")) == "Tesseract"
    
    for obj in metadata['objects']:
        object_img_path = os.path.join(SEGMENTED_OBJECTS_DIR, obj['file_name'])
        image = cv2.imread(object_img_path)
        if USE_TESSERACT:
            extracted_text = pytesseract.image_to_string(image)
        else:
            reader = easyocr.Reader(['en'])
            extracted_text = reader.readtext(image, detail=0)
        obj['extracted_text'] = extracted_text
    
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=4)

    st.success("Text extraction completed and metadata updated.")

#Summarize text
    
    for obj in metadata['objects']:
        if 'extracted_text' in obj and obj['extracted_text']:
            text = obj['extracted_text']
            summary = summarizer(text, max_length=150, min_length=30, do_sample=False)
            obj['summary'] = summary[0]['summary_text']
        else:
            obj['summary'] = "No text extracted"
    
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=4)

    st.success("Summarization completed and metadata updated.")

#Display mapped data
    
    mapped_data = {"master_image": {"file_name": uploaded_file.name, "objects": []}}
    for obj in metadata['objects']:
        mapped_data['master_image']['objects'].append({
            "unique_id": obj.get('unique_id', 'N/A'),
            "file_name": obj.get('file_name', 'N/A'),
            "label": obj.get('label', 'N/A'),
            "confidence": obj.get('confidence', 'N/A'),
            "extracted_text": obj.get('extracted_text', 'N/A'),
            "summary": obj.get('summary', 'N/A')
        })
    
    mapped_data_path = os.path.join(SEGMENTED_OBJECTS_DIR, "mapped_data.json")
    with open(mapped_data_path, "w") as f:
        json.dump(mapped_data, f, indent=4)
    
    st.success("Data mapping completed and saved to mapped_data.json.")
    
#Annotate and display image
    
    annotated_image_path = os.path.join(SEGMENTED_OBJECTS_DIR, "annotated_image.jpg")
    image_cv = cv2.imread(uploaded_file.name)
    for obj in mapped_data['master_image']['objects']:
        unique_id = obj.get('unique_id', 'N/A')
        file_name = obj.get('file_name', 'N/A')
        x_min, y_min, x_max, y_max = map(int, obj.get('bounding_box', [0, 0, 100, 100]))
        cv2.rectangle(image_cv, (x_min, y_min), (x_max, y_max), (0, 255, 0), 2)
        label = f"ID: {unique_id} | {file_name}"
        cv2.putText(image_cv, label, (x_min, y_min-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    
    cv2.imwrite(annotated_image_path, image_cv)
    st.image(annotated_image_path, caption='Annotated Image', use_column_width=True)
    
#Create summary table
    
    data = []
    for obj in mapped_data['master_image']['objects']:
        data.append({
            "Unique ID": obj.get('unique_id', 'N/A'),
            "File Name": obj.get('file_name', 'N/A'),
            "Label": obj.get('label', 'N/A'),
            "Confidence": obj.get('confidence', 'N/A'),
            "Extracted Text": obj.get('extracted_text', 'N/A'),
            "Summary": obj.get('summary', 'N/A')
        })
    
    df = pd.DataFrame(data)
    summary_table_path = os.path.join(SEGMENTED_OBJECTS_DIR, "summary_table.csv")
    df.to_csv(summary_table_path, index=False)
    
    st.success("Summary table saved as summary_table.csv.")


# In[ ]:




