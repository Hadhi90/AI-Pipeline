#!/usr/bin/env python
# coding: utf-8

# In[ ]:


## Importing the Needed Packages

import torch
from torchvision import models, transforms
from PIL import Image
import json
import os

# We will make use of pre-trained Faster R-CNN model
model = models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
model.eval()

# Transformation for the input image
transform = transforms.Compose([
    transforms.ToTensor()
])

# Load metadata
output_dir = "project_root/data/segmented_objects/"
metadata_path = os.path.join(output_dir, "your_metadata_file.json")

with open(metadata_path, "r") as f:
    metadata = json.load(f)

# Identifying the objects
for obj in metadata['objects']:
    # Load the object image
    object_img_path = os.path.join(output_dir, obj['file_name'])
    image = Image.open(object_img_path)
    image_tensor = transform(image).unsqueeze(0)
    
    # Perform object detection
    with torch.no_grad():
        predictions = model(image_tensor)
    
    # Extract the labels and scores
    labels = predictions[0]['labels'].numpy()
    scores = predictions[0]['scores'].numpy()
    
    # Get the highest confidence label
    label_idx = scores.argmax()
    obj_label = labels[label_idx]
    obj_confidence = scores[label_idx]
    
    # Update metadata with the object label and confidence
    obj['label'] = str(obj_label)
    obj['confidence'] = float(obj_confidence)

# Save the updated metadata
with open(metadata_path, "w") as f:
    json.dump(metadata, f, indent=4)

print("Object identification completed and metadata updated.")

