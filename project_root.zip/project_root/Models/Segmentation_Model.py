#!/usr/bin/env python
# coding: utf-8

# ## Step 1 : Segmentation 

# In[ ]:


# importing the needed packages 

import torch
from torchvision import models, transforms
from PIL import Image
import cv2
import matplotlib.pyplot as plt
import numpy as np

# Here i am using pre-trained Mask R-CNN model
model = models.detection.maskrcnn_resnet50_fpn(pretrained=True)
model.eval()

# we will define image transformation
transform = transforms.Compose([
    transforms.ToTensor()
])

# Preprocessing the image from the directory
image = Image.open("project_root/data/input_images/sample.jpg")
image_tensor = transform(image).unsqueeze(0)

# we will perform segmentation here, 
with torch.no_grad():
    predictions = model(image_tensor)

# Extract masks and bounding boxes
masks = predictions[0]['masks'].numpy()
boxes = predictions[0]['boxes'].numpy()

# Finally we will visualize the results
image_np = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
for i in range(len(masks)):
    mask = masks[i, 0]
    image_np[mask > 0.5] = [0, 255, 0]  # Apply green color to segmented areas

plt.imshow(cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB))
plt.show()

