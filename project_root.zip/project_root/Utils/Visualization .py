#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Needed Packages

import cv2
import json
import os

# Paths
output_dir = "project_root/data/output/"
input_image_path = "project_root/data/input_images/sample.jpg"
metadata_path = os.path.join(output_dir, "mapped_data.json")

# Input Image
image = cv2.imread(input_image_path)

with open(metadata_path, "r") as f:
    mapped_data = json.load(f)

#annotations
for obj in mapped_data['master_image']['objects']:
    unique_id = obj.get('unique_id', 'N/A')
    file_name = obj.get('file_name', 'N/A')
    x, y, w, h = 50, 50, 100, 100  
    cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
    label = f"ID: {unique_id} | {file_name}"
    cv2.putText(image, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

# Save
annotated_image_path = os.path.join(output_dir, "annotated_image.jpg")
cv2.imwrite(annotated_image_path, image)

print("Annotated image saved.")


# In[ ]:


## Packages

import pandas as pd

#mapped data
with open(metadata_path, "r") as f:
    mapped_data = json.load(f)

#Data Frame for Sumamry Table
data = []
for obj in mapped_data['master_image']['objects']:
    data.append({
        "Unique ID": obj.get('unique_id', 'N/A'),
        "File Name": obj.get('file_name', 'N/A'),
        "Label": obj.get('label', 'N/A'),
        "Confidence": obj.get('confidence', 'N/A'),
        "Extracted Text": obj.get('extracted_text', 'N/A'),
        "Summary": obj.get('summary', 'N/A')
    })

df = pd.DataFrame(data)

# Save
summary_table_path = os.path.join(output_dir, "summary_table.csv")
df.to_csv(summary_table_path, index=False)

print("Summary table saved as summary_table.csv.")

