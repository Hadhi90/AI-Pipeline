#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Preprocessing the image from the directory
image = Image.open("project_root/data/input_images/sample.jpg")
image_tensor = transform(image).unsqueeze(0)

