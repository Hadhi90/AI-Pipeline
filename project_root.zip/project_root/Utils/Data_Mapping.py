#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Needed Packages

import json
import os

#metadata file
output_dir = "project_root/data/segmented_objects/"
metadata_path = os.path.join(output_dir, "your_metadata_file.json")

# Loading
with open(metadata_path, "r") as f:
    metadata = json.load(f)

# Create a dictionary
mapped_data = {
    "master_image": {
        "file_name": "input_image.jpg",  # Replace with actual master image file name
        "objects": []
    }
}

# Map object data
for obj in metadata['objects']:
    mapped_data['master_image']['objects'].append({
        "unique_id": obj.get('unique_id', 'N/A'),
        "file_name": obj.get('file_name', 'N/A'),
        "label": obj.get('label', 'N/A'),
        "confidence": obj.get('confidence', 'N/A'),
        "extracted_text": obj.get('extracted_text', 'N/A'),
        "summary": obj.get('summary', 'N/A')
    })

# Save
mapped_data_path = os.path.join(output_dir, "mapped_data.json")
with open(mapped_data_path, "w") as f:
    json.dump(mapped_data, f, indent=4)

print("Data mapping completed and saved to mapped_data.json.")

